#include "Conjunto.h"

Conjunto::Conjunto(A_type x, B_Type y)
{
    a=x;
    b=y;
}
Conjunto::Conjunto(A_type x, B_Type y, C_Type z){

    a=x;
    b=y;
    c=z;

}

Conjunto::~Conjunto()
{
    //dtor
}
